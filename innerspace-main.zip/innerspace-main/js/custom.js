$(document).ready(function() {
    // Banner slider
    $('.banner-slider').owlCarousel({
        items: 1,
        loop: true,
        nav: false,
        dots: false,
        autoplay: true
    });
});